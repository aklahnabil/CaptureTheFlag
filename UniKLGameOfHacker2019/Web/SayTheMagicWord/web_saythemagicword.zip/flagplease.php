<?php
$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
  case 'PLEASE':
      //Here Handle PLEASE Request
      echo 'CORRECT! '.$method.' is the MAGIC word. The flag is uniklgoh19{a1c5755d1fbc13fbce8d07dc5993a73d} :D';
      break;
  Default:
    echo 'WRONG! That\'s not MAGIC at all. No flag for you! =P';
  break;
}
?>
