Hello guys, can you help me to continue my forensic investigation. 
Here is the evidence that you need to further investigate.
- MrKay