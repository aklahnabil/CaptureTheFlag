/*
 * UniKL GoH 2019 - CahayaBintang
 * gcc cahayabintang.c -o cahayabintang
 * socat TCP4-LISTEN:11337,reuseaddr,fork EXEC:"./cahayabintang" > /dev/null 2>&1 &
*/
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define MAXN 128

void tunjuk_bendera() {
  FILE *fp;
  char password[MAXN];
  char input[MAXN];
  char flag[MAXN];

  fp = fopen("password.txt", "r");
  if (fp == NULL) {
    puts("Kesilapan: katalaluan tidak dijumpai");
    return;
  }

  printf("Katalaluan: ");
  getchar();
  fgets(input, sizeof(input), stdin);
  strtok(input, "\n");

  fgets(password, sizeof(input), fp);
  strtok(password, "\n");

  if (strcmp(input, password) == 0) {
      fp = fopen("flag.txt", "r");
      if (fp == NULL) {
        puts("Kesilapan: bendera tidak dijumpai");
        return;
      }
      fgets(flag, sizeof(flag), fp);
      puts(flag);
  }

}

void tunjuk_segitiga() {
  int i = 0, j = 0;
  for (i = 0; i < 10; i++) {
    for (j = 0; j < 10 - (i + 1); j++) {
      printf(" ");
    }
    for (j = 0; j < (i + 1) * 2 - 1; j++) {
      printf("*");
    }
    puts("");
  }
  puts("");
}

void tunjuk_segitiga_kanan() {
  int i = 0, j = 0;
  for (i = 0; i < 10; i++) {
    for (j = 0; j < (i + 1); j++) {
      printf("*");
    }
    puts("");
  }
  puts("");
}

void service() {
  FILE *fp;
  char path[MAXN];
  char lang[MAXN];
  char menu[MAXN];
  int choice;

  printf("Pilih bahasa (my/en): ");
  fgets(lang, sizeof(lang), stdin);
  strtok(lang, "\n");

  snprintf(path, MAXN, "languages/%s.lang", lang);

  fp = fopen(path, "r");

  if (fp == NULL) {
    puts("Kesilapan: bahasa tidak dijumpai");
    return;
  }

  while (fgets(menu, sizeof(menu), fp)) {
    strtok(menu, "\n");
    printf("%s\n", menu);
  }
  fclose(fp);

  choice = (getchar() - '0');

  if (choice == 1) {
    tunjuk_segitiga();
  } else if (choice == 2) {
    tunjuk_segitiga_kanan();
  } else if (choice == 3) {
    tunjuk_bendera();
  }
}

void init() {
  char buff[1];
  buff[0] = 0;
  setvbuf(stdout, buff, _IOFBF, 1);
  alarm(60);
}
 
int main() {
  init();
  service();
  return 0;
}
